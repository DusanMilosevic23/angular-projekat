import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { OrderModel } from '../../models/order.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cart',
  imports: [
    MatCardModule,
    MatTableModule,
    RouterLink,
    MatButtonModule,
    MatIconModule
  ],
  templateUrl: './cart.html',
  styleUrl: './cart.css',
})
export class Cart {

  displayedColumns = [
    'toyName',
    'toyType',
    'ageGroup',
    'count',
    'createdAt',
    'options'
  ]

  constructor(public router: Router) {

    if (!AuthService.getActiveUser()) {
      router.navigate(['/login'])
      return
    }

  }

  reloadComponent() {

    this.router.navigateByUrl('/', { skipLocationChange: true })
      .then(() => {
        this.router.navigate(['/cart'])
      })

  }

  formatDate(date: string) {
    return new Date(date).toLocaleString()
  }

  getOrders() {
    return AuthService.getOrdersByState('w')
  }

  getPaidOrders() {
    return AuthService.getOrdersByState('p')
  }

  getCanceledOrders() {
    return AuthService.getOrdersByState('c')
  }

  removeOrder(order: OrderModel) {
    AuthService.cancelOrder(order.createdAt)
    this.reloadComponent()
  }

  payAll() {
    AuthService.payOrders()
    this.reloadComponent()
  }



  rateOrder(order: OrderModel) {

  Swal.fire({
    title: 'Rate this toy (1-5)',
    input: 'number',
    inputAttributes: {
      min: '1',
      max: '5'
    },
    inputValue: 5,
    showCancelButton: true
  }).then(result => {

    if (result.value) {

      const rating = Number(result.value);

      if (rating >= 1 && rating <= 5) {
        AuthService.addRating(order.toyId, rating);
        Swal.fire('Success', 'Rating added!', 'success');
      }
    }

  });
}



  showBarcode(order: OrderModel) {

    const barcode = new Date(order.createdAt).getTime()

    const src =
      `https://quickchart.io/barcode?type=code128&text=${barcode}&width=280&includeText=true`

    Swal.fire({
      title: order.toyName,
      html: `<img src="${src}" />`
    })
  }

}
