import { Component, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToyModel } from '../../models/toy.model';
import { Utils } from '../utils';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../services/auth.service';
import { ToyService } from '../services/toy.service';
import { Loading } from '../loading/loading';
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-details',
  standalone: true,
  imports: [
    MatCardModule,
    MatListModule,
    MatIconModule,
    MatButtonModule,
    RouterLink,
    Loading
  ],
  templateUrl: './details.html',
  styleUrls: ['./details.css'],
})
export class Details {
  public authService = AuthService;
  toy = signal<ToyModel | null>(null);
  randomRatings: Record<string, number> = {};

  constructor(private route: ActivatedRoute, public utils: Utils) {
    // Pratimo parametre rute
    this.route.params.subscribe(params => {
      const id = params['id'];
      if (!id) return;

      // Dohvatamo igračku po ID, mapiranje isto kao u home.ts
ToyService.getToyById(id)
  .then(rsp => {
    console.log(rsp); // 👈 DODAJ OVO

    if(!rsp) return;

    const toyProcessed: ToyModel = {
      id: String((rsp as any).toyId),
      name: rsp.name,
      imageUrl: rsp.imageUrl,
      gender: this.assignGender(rsp),

      description: rsp.description,
      productionDate: rsp.productionDate,

      type: rsp.type,
      ageGroup: rsp.ageGroup
    };

    this.toy.set(toyProcessed);
  });

    });

  }

private assignGender(toy: any): 'Male' | 'Female' | 'Unisex' {

  const name = toy.name?.toLowerCase() ?? ''
  const type = toy.type?.name ?? ''

  // Specijalne lutke za female
  if (name.includes('plišana') || name.includes('crtanje') || name.includes('princeze') || name.includes('jednorog')) {
    return 'Female'
  }

  switch(type) {
    case 'Figura':
    case 'Vozilo':
    case 'Konstruktorski set(lego figurice)':
      return 'Male'
    case 'Kreativni set(bojanke)':
    case 'Plišana igracka':
      return 'Female'
    default:
      return 'Unisex'
  }
}

}