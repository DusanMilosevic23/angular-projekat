import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { Router, RouterLink } from '@angular/router';
import { MatSelectModule } from '@angular/material/select';

import { UserModel } from '../../models/user.model';
import { Alerts } from '../alerts';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    FormsModule,
    RouterLink,
    MatSelectModule
  ],
  templateUrl: './signup.html',
  styleUrls: ['./signup.css']
})
export class Signup {

  user: Partial<UserModel> = {
    email: '',
    firstName: '',
    lastName: '',
    phone: '',
    address: '',
    password: '',
    favoriteType: '',
    preferredAgeGroup: ''
  }

  repeat: string = ''

  types = signal<string[]>([])
  ageGroups = signal<string[]>([])

  constructor(public router: Router) {

    // isto kao u user.ts
    this.types.set(['Slagalica', 'Slikovnica', 'Figura', 'Autić'])
    this.ageGroups.set(['0-2', '3-5', '6-9', '10+'])

  }

  doSignup() {

    if (AuthService.existsByEmail(this.user.email!)) {
      Alerts.error('Email already registered!')
      return
    }

    if (
      !this.user.firstName ||
      !this.user.lastName ||
      !this.user.address ||
      !this.user.phone ||
      !this.user.favoriteType ||
      !this.user.preferredAgeGroup
    ) {
      Alerts.error('All fields must be filled!')
      return
    }

    if (!this.user.password || this.user.password.length < 6) {
      Alerts.error('Password must be at least 6 characters long!')
      return
    }

    if (this.user.password !== this.repeat) {
      Alerts.error('Passwords do not match!')
      return
    }

    AuthService.createUser(this.user)

    Alerts.success('Account created successfully')

    this.router.navigate(['/login'])
  }
}