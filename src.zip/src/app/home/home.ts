import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToyModel } from '../../models/toy.model';
import { RouterLink } from "@angular/router";
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';

import { Utils } from '../utils';
import { AuthService } from '../services/auth.service';
import { ToyService } from '../services/toy.service';
import { Loading } from '../loading/loading';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    FormsModule,
    Loading
  ],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {

  public authService = AuthService;

  toys = signal<ToyModel[]>([])
  filteredToys = signal<ToyModel[]>([])

  search = ''
  toyType = ''
  ageGroup = ''
  gender = ''
  randomRatings: Record<string, number> = {};

  constructor(public utils: Utils) {

    ToyService.getToys()
      .then(rsp => {

        const toysProcessed: ToyModel[] = rsp.map((toy: any) => ({
          id: String(toy.toyId),
          name: toy.name,
          imageUrl: toy.imageUrl,
          gender: this.assignGender(toy),
          type: {
            id: toy.type?.id ?? 0,
            name: toy.type?.name ?? String(toy.type)
          },
          ageGroup: {
            id: toy.ageGroup?.id ?? 0,
            name: toy.ageGroup?.name ?? String(toy.ageGroup)
          }
        }));

        this.toys.set(toysProcessed)
        this.filteredToys.set(toysProcessed)

      })
      .catch(err => console.error(err));
  }

  getTypes() {
    const set = new Set<string>()
    this.toys().forEach(t => set.add(t.type.name))
    return Array.from(set)
  }

  getAgeGroups() {
    const set = new Set<string>()
    this.toys().forEach(t => set.add(t.ageGroup.name))
    return Array.from(set)
  }

  getGenders() {
    return ['Male', 'Female' ,'Unisex']
  }

  filter() {

    const filtered = this.toys()

      .filter(t => {
        if (this.search == '') return true
        const q = this.search.toLowerCase()
        return t.name.toLowerCase().includes(q)
      })

      .filter(t => {
        if (this.toyType == '') return true
        return t.type.name == this.toyType
      })

      .filter(t => {
        if (this.ageGroup == '') return true
        return t.ageGroup.name == this.ageGroup
      })

      .filter(t => {
        if (this.gender == '') return true
        return t.gender.toLowerCase() === this.gender.toLowerCase()
      })

    this.filteredToys.set(filtered)
  }

getRating(toyId: string): number {

  const ratings = AuthService.getRatingsForToy(toyId);

  if (ratings.length > 0) {
    const avg = ratings.reduce((a, b) => a + b, 0) / ratings.length;
    return Math.round(avg);
  }

  // 👉 ako nema ocena → koristi cached random
  if (!this.randomRatings[toyId]) {
    this.randomRatings[toyId] = Math.floor(Math.random() * 5) + 1;
  }

  return this.randomRatings[toyId];
}

private assignGender(toy: any): 'Male' | 'Female' | 'Unisex' {

  const name = toy.name?.toLowerCase() ?? ''
  const type = toy.type?.name ?? ''

  // Specijalne lutke za female
  if (name.includes('plišana') || name.includes('crtanje') || name.includes('princeze') || name.includes('jednorog')) {
    return 'Female'
  }

  switch(type) {
    case 'Figura':
    case 'Vozilo':
    case 'Konstruktorski set(lego figurice)':
      return 'Male'
    case 'Kreativni set(bojanke)':
    case 'Plišana igracka':
      return 'Female'
    default:
      return 'Unisex'
  }
}

}