export class DataService {

  static getToyBrands() {
    return [
      { id: 1, name: 'LEGO', priceImpact: 1.3 },
      { id: 2, name: 'Hasbro', priceImpact: 1.1 },
      { id: 3, name: 'Mattel', priceImpact: 1.0 },
    ];
  }

  static getToyOptions() {
    return [
      { id: 1, name: 'Standard Pack', price: 5 },
      { id: 2, name: 'Deluxe Pack', price: 10 },
      { id: 3, name: 'Collector Edition', price: 25 },
    ];
  }
}