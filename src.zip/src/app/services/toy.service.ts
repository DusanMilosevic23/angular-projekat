import axios from 'axios';
import { ToyModel } from '../../models/toy.model';

const client = axios.create({
  baseURL: 'https://toy.pequla.com/api',
  headers: {
    'Accept': 'application/json',
    'X-Name': 'KVA_2026/dev'
  },
  validateStatus(status) {
    // prihvati sve 2xx statuse
    return status >= 200 && status < 300;
  }
});

export class ToyService {
  static async getToys(): Promise<ToyModel[]> {
    const resp = await client.get<ToyModel[]>('/toy');
    return resp.data ?? [];
  }

  static async getToyById(id: string): Promise<ToyModel | null> {
    const resp = await client.get<ToyModel>('/toy/' + id);
    return resp.data ?? null;
  }

  static async getTypes(): Promise<string[]> {
    try {
      const resp = await client.get<ToyModel[]>('/toy');
      const types = resp.data?.map(t => t.type.name) ?? [];
      // izbaci duplikate
      return Array.from(new Set(types));
    } catch {
      return [];
    }
  }

  static async getAgeGroups(): Promise<string[]> {
    try {
      const resp = await client.get<ToyModel[]>('/toy');
      const ages = resp.data?.map(t => t.ageGroup.name) ?? [];
      return Array.from(new Set(ages));
    } catch {
      return [];
    }
  }
}