import { UserModel } from "../../models/user.model";
import { ToyModel } from "../../models/toy.model";
import { OrderModel } from "../../models/order.model";

const USERS = 'users';
const ACTIVE = 'active';

export class AuthService {
    static getUsers(): UserModel[] {
        if (!localStorage.getItem(USERS)) {

            const baseUser: UserModel = {
                email: 'user@example.com',
                password: 'user123',
                favoriteType: 'Puzzle',
                preferredAgeGroup: '6-8',
                firstName: 'Example',
                lastName: 'User',
                phone: '0653093267',
                address: 'Danijelova 32',
                orders: []
            };

            localStorage.setItem(USERS, JSON.stringify([baseUser]));
        }
        return JSON.parse(localStorage.getItem(USERS)!) as UserModel[];
    }

    static login(email: string, password: string): boolean {
        const users = this.getUsers();
        for (let u of users) {
            if (u.email === email && u.password === password) {
                localStorage.setItem(ACTIVE, email);
                return true;
            }
        }
        return false;
    }

    static getActiveUser(): UserModel | null {
        const users = this.getUsers();
        for (let u of users) {
            if (u.email === localStorage.getItem(ACTIVE)) {
                return u;
            }
        }
        return null;
    }

    static updateActiveUser(newUserData: Partial<UserModel>) {
        const users = this.getUsers();
        for (let u of users) {
            if (u.email === localStorage.getItem(ACTIVE)) {

                u.firstName = newUserData.firstName ?? u.firstName;
                u.lastName = newUserData.lastName ?? u.lastName;
                u.address = newUserData.address ?? u.address;
                u.phone = newUserData.phone ?? u.phone;
                u.favoriteType = newUserData.favoriteType ?? u.favoriteType;
                u.preferredAgeGroup = newUserData.preferredAgeGroup ?? u.preferredAgeGroup;
            }
        }
        localStorage.setItem(USERS, JSON.stringify(users));
    }

    static updateActiveUserPassword(newPassword: string) {
        const users = this.getUsers();
        for (let u of users) {
            if (u.email === localStorage.getItem(ACTIVE)) {
                u.password = newPassword;
            }
        }
        localStorage.setItem(USERS, JSON.stringify(users));
    }

    static logout() {
        localStorage.removeItem(ACTIVE);
    }

    static createOrder(order: Partial<OrderModel>, toy: ToyModel) {
        const users = this.getUsers();
        for (let u of users) {
            if (u.email === localStorage.getItem(ACTIVE)) {

                const newOrder: OrderModel = {
                    ...order,
                    state: 'w',
                    toyId: toy.id,
                    toyName: toy.name,
                    toyType: toy.type.name,
                    ageGroup: toy.ageGroup.name,
                    createdAt: new Date().toISOString()
                } as OrderModel;

                u.orders.push(newOrder);
            }
        }

        localStorage.setItem(USERS, JSON.stringify(users));
    }

    static getOrdersByState(state: 'w' | 'p' | 'c') {
        const users = this.getUsers();
        for (let u of users) {
            if (u.email === localStorage.getItem(ACTIVE)) {
                return u.orders.filter(o => o.state === state);
            }
        }
        return [];
    }

    static cancelOrder(createdAt: string) {
        const users = this.getUsers();
        for (let u of users) {
            if (u.email === localStorage.getItem(ACTIVE)) {

                for (let o of u.orders) {

                    if (o.createdAt === createdAt) {
                        o.state = 'c';
                    }
                }
            }
        }
        localStorage.setItem(USERS, JSON.stringify(users));
    }

    static payOrders() {
        const users = this.getUsers();
        for (let u of users) {

            if (u.email === localStorage.getItem(ACTIVE)) {

                for (let o of u.orders) {

                    if (o.state === 'w') {
                        o.state = 'p';
                    }
                }
            }
        }
        localStorage.setItem(USERS, JSON.stringify(users));
    }

        static createUser(user: Partial<UserModel>) {
        const users = this.getUsers()
        user.orders = []
        users.push(user as UserModel)
        localStorage.setItem(USERS, JSON.stringify(users))
    }

    static existsByEmail(email: string) {
        const users = this.getUsers()
        for (let u of users) {
            if (u.email === email) return true
        }
        return false
    }


    static addRating(toyId: string, rating: number) {
    const users = this.getUsers();
    for (let u of users) {
        if (u.email === localStorage.getItem(ACTIVE)) {

            if (!u.ratings) {
                (u as any).ratings = [];
            }

            (u as any).ratings.push({
                toyId,
                value: rating
            });
        }
    }
    localStorage.setItem(USERS, JSON.stringify(users));
}

    static getRatingsForToy(toyId: string): number[] {
        const users = this.getUsers();
        let allRatings: number[] = [];
        for (let u of users) {

            const ratings = (u as any).ratings || [];

            for (let r of ratings) {
                if (r.toyId === toyId) {
                    allRatings.push(r.value);
                }
            }
        }
        return allRatings;
    }

}