import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatListModule } from '@angular/material/list';
import { ToyService } from '../services/toy.service';
import { Loading } from '../loading/loading';
import { Alerts } from '../alerts';
import { ToyModel } from '../../models/toy.model';
import { Utils } from '../utils';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [
    CommonModule,
    
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatSelectModule,
    MatListModule,
    FormsModule,
    Loading
  ],
  templateUrl: './user.html',
  styleUrls: ['./user.css']
})
export class User {

  public activeUser = AuthService.getActiveUser();

  types = signal<string[]>([]);
  ageGroups = signal<string[]>([]);
  recommended = signal<ToyModel[]>([]);
  loading = signal(true);

  oldPassword = '';
  newPassword = '';
  passRepeat = '';

  constructor(
    private router: Router,
    public utils: Utils
  ) {
    if (!this.activeUser) {
      router.navigate(['/login']);
      return;
    }

    // Popuni tipove i ageGroups (može i dinamički)
    this.types.set(['Slagalica', 'Slikovnica', 'Figura', 'Autić']);
    this.ageGroups.set(['0-2', '3-5', '6-9', '10+']);

    // Dohvati sve toys i izaberi "dinamičkih" 4 recommended
    ToyService.getToys()
      .then(toys => {
        if (!toys || toys.length === 0) {
          this.recommended.set([]);
          return;
        }

        const ageGroupsSeen = new Set<string>();
        const recommended: ToyModel[] = [];

        for (const toy of toys) {
          if (!ageGroupsSeen.has(toy.ageGroup.name)) {
            recommended.push(toy);
            ageGroupsSeen.add(toy.ageGroup.name);
          }
          if (recommended.length >= 4) break; // uzmi samo 4 različita uzrasta
        }

        this.recommended.set(recommended);
      })
      .finally(() => this.loading.set(false));
  }

  goToDetails(toyId: string): void {
  // Navodimo rutu kao niz stringova (Angular preporuka)
  this.router.navigate(['/details', toyId]);
}

  getAvatarUrl(): string {
    if (!this.activeUser) return '';
    return `https://ui-avatars.com/api/?name=${this.activeUser.firstName}+${this.activeUser.lastName}`;
  }

  updateUser(): void {
    if (!this.activeUser) return;
    AuthService.updateActiveUser(this.activeUser);
    alert('User updated successfully');
  }

  updatePassword(): void {
    Alerts.confirm('Are you sure you want to change the password?',
      () => {
        if (this.oldPassword != this.activeUser?.password) {
          Alerts.error('Invalid old password');
          return;
        }
        if (this.newPassword.length < 6) {
          Alerts.error('Password must be at least 6 characters long');
          return;
        }
        if (this.newPassword != this.passRepeat) {
          Alerts.error('Passwords dont match');
          return;
        }
        if (this.newPassword == this.activeUser?.password) {
          Alerts.error('New password cant be the same as the old one');
          return;
        }

        AuthService.updateActiveUserPassword(this.newPassword);
        Alerts.success('Password updated successfully');
        AuthService.logout();
        this.router.navigate(['/login']);
      });
  }

  
}