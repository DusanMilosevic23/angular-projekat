import { Component, signal } from '@angular/core';
import { ToyModel } from '../../models/toy.model';
import { DataService } from '../services/data.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToyService } from '../services/toy.service';
import { MatCardModule } from '@angular/material/card';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { Loading } from '../loading/loading';
import { Utils } from '../utils';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatFormField } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { OrderModel } from '../../models/order.model';
import { AuthService } from '../services/auth.service';
import { Alerts } from '../alerts';

@Component({
  selector: 'app-order',
  imports: [
    MatCardModule,
    FormsModule,
    MatFormField,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    Loading,
    MatListModule,
    MatIconModule
  ],
  templateUrl: './order.html',
  styleUrls: ['./order.css'],
})
export class Order {
  toy = signal<ToyModel | null>(null);
  brands = DataService.getToyBrands();
  toyTypes = DataService.getToyOptions();
  randomRatings: Record<string, number> = {};

  order: Partial<OrderModel> = {
    brandId: this.brands[0]?.id ?? null,
    toyTypeId: this.toyTypes[0]?.id ?? null,
    ageGroup: 'a',
    count: 1
  };

  constructor(
    public router: Router,
    private route: ActivatedRoute,
    public utils: Utils
  ) {
    // Redirect ako nema aktivnog korisnika
    if (!AuthService.getActiveUser()) {
      this.router.navigate(['/login']);
      return;
    }

    this.route.params.subscribe(params => {
      const id = params['id'];
      if (id) {
        ToyService.getToyById(id)
          .then(rsp => {

            if (!rsp) return;

            const toyProcessed: ToyModel = {
              id: String((rsp as any).toyId),
              name: rsp.name,
              imageUrl: rsp.imageUrl,
              gender: this.assignGender(rsp),
              type: rsp.type,
              ageGroup: rsp.ageGroup
            };

            this.toy.set(toyProcessed);

          })
      }
    });
  }

  calculateTotal(): number {
    const toyType = this.toyTypes.find(t => t.id === this.order.toyTypeId);
    const brand = this.brands.find(b => b.id === this.order.brandId);
    if (!toyType || !brand || !this.order.count) return 0;

    const toyCost = toyType.price;
    const brandImpact = brand.priceImpact;
    const ageMultiplier = this.order.ageGroup === 'c' ? 0.5 : 1;

    return toyCost * brandImpact * this.order.count * ageMultiplier;
  }

  placeOrder(): void {
    const total = this.calculateTotal();
    Alerts.confirm(
      `Are you sure you want to place the order for ${total.toFixed(2)} EUR?`,
      () => {
        const activeToy = this.toy();
        if (!activeToy) {
          Alerts.error('Toy not loaded!');
          return;
        }
        AuthService.createOrder(this.order, activeToy);
        this.router.navigate(['/cart']);
      }
    );
  }


private assignGender(toy: any): 'Male' | 'Female' | 'Unisex' {

  const name = toy.name?.toLowerCase() ?? ''
  const type = toy.type?.name ?? ''

  // Specijalne lutke za female
  if (name.includes('plišana') || name.includes('crtanje') || name.includes('princeze') || name.includes('jednorog')) {
    return 'Female'
  }

  switch(type) {
    case 'Figura':
    case 'Vozilo':
    case 'Konstruktorski set(lego figurice)':
      return 'Male'
    case 'Kreativni set(bojanke)':
    case 'Plišana igracka':
      return 'Female'
    default:
      return 'Unisex'
  }
}
}