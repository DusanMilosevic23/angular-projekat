export interface UserModel {  
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone: string;
  address: string;
  orders: any[];

  favoriteType?: string;
  preferredAgeGroup?: string;

  ratings?: {
  toyId: string;
  value: number;
}[];
}