export interface OrderModel {
    toyId: string
    toyName: string
    brandId: number
    optionId?: number
    toyTypeId: number
    ageGroup: 'a' | 'c'
    state: 'w' | 'c' | 'p'
    count: number
    createdAt: string
}