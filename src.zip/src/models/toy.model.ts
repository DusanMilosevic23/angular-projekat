export interface ToyModel { 
  id: string;      
  name: string;
  imageUrl: string;
  gender: string;
  type: {
    id: number;
    name: string;
  };
  ageGroup: {
    id: number;
    name: string;
  };
}

export interface Rating {
  userId: string;
  value: number; // 1-5
  comment?: string;
  date: string;
}
