import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-E6UOHKUB.js";
import "./chunk-KNNVXG53.js";
import "./chunk-AIEYJCOW.js";
import "./chunk-4KKGBAGR.js";
import "./chunk-PVSHPFSN.js";
import "./chunk-2VFNXXBB.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-UWZGBUQN.js";
import "./chunk-VJCEI5DD.js";
import "./chunk-BKD3HGKK.js";
import "./chunk-WTBKZDBF.js";
import "./chunk-37RIRWGK.js";
import "./chunk-PA5WTJLB.js";
import "./chunk-653SOEEV.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
